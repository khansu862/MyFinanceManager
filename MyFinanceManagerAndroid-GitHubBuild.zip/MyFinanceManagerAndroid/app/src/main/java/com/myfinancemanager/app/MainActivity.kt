package com.myfinancemanager.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingSms: PendingSms? = null
    private val sentAction = "com.myfinancemanager.app.SMS_SENT"
    private val deliveredAction = "com.myfinancemanager.app.SMS_DELIVERED"
    private val pendingStatuses = ConcurrentHashMap<String, String>()

    data class PendingSms(val phone: String, val message: String, val transactionId: String)

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val transactionId = intent.getStringExtra("transactionId") ?: ""
            when (intent.action) {
                sentAction -> {
                    val status = if (resultCode == Activity.RESULT_OK) "Sent" else "Failed"
                    val detail = if (resultCode == Activity.RESULT_OK) {
                        "Accepted by the mobile network"
                    } else {
                        "Android SMS error code: $resultCode"
                    }
                    if (transactionId.isNotBlank()) pendingStatuses[transactionId] = status
                    notifyWeb(transactionId, status, detail)
                }
                deliveredAction -> {
                    val status = if (resultCode == Activity.RESULT_OK) "Delivered" else "Delivery failed"
                    val detail = if (resultCode == Activity.RESULT_OK) {
                        "Delivery report received from the network"
                    } else {
                        "Network did not confirm delivery (code $resultCode)"
                    }
                    if (transactionId.isNotBlank()) pendingStatuses[transactionId] = status
                    notifyWeb(transactionId, status, detail)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidSmsBridge(), "AndroidSms")

        val filter = IntentFilter().apply {
            addAction(sentAction)
            addAction(deliveredAction)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(smsReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(smsReceiver, filter)
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidSmsBridge {
        @JavascriptInterface
        fun sendSms(phoneRaw: String, messageRaw: String, transactionIdRaw: String) {
            runOnUiThread {
                val phone = phoneRaw.trim()
                val message = messageRaw.trim()
                val transactionId = transactionIdRaw.trim()
                if (phone.isBlank() || message.isBlank()) {
                    notifyWeb(transactionId, "Failed", "Phone number or message is empty")
                    return@runOnUiThread
                }
                if (!phone.matches(Regex("^\\+?[0-9 ()-]{7,20}$"))) {
                    notifyWeb(transactionId, "Failed", "Please correct the parent's phone number")
                    return@runOnUiThread
                }
                if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    pendingSms = PendingSms(phone, message, transactionId)
                    requestPermissions(arrayOf(Manifest.permission.SEND_SMS), REQUEST_SEND_SMS)
                    return@runOnUiThread
                }
                sendNow(PendingSms(phone, message, transactionId))
            }
        }
    }

    private fun sendNow(sms: PendingSms) {
        try {
            val smsManager = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            val parts = smsManager.divideMessage(sms.message)
            val sentIntents = ArrayList<PendingIntent>()
            val deliveryIntents = ArrayList<PendingIntent>()
            parts.forEachIndexed { index, _ ->
                val sent = Intent(sentAction).setPackage(packageName)
                    .putExtra("transactionId", sms.transactionId)
                val delivered = Intent(deliveredAction).setPackage(packageName)
                    .putExtra("transactionId", sms.transactionId)
                val base = (System.currentTimeMillis().toInt() and 0x00ffffff) + index
                sentIntents.add(PendingIntent.getBroadcast(
                    this, base, sent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                ))
                deliveryIntents.add(PendingIntent.getBroadcast(
                    this, base + 100000, delivered, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                ))
            }
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(sms.phone, null, parts, sentIntents, deliveryIntents)
            } else {
                smsManager.sendTextMessage(sms.phone, null, sms.message, sentIntents.first(), deliveryIntents.first())
            }
            notifyWeb(sms.transactionId, "Sending", "SMS submitted to Android")
        } catch (e: Exception) {
            notifyWeb(sms.transactionId, "Failed", e.message ?: "Unable to send SMS")
            Toast.makeText(this, "SMS could not be sent", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_SEND_SMS) {
            val request = pendingSms
            pendingSms = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && request != null) {
                sendNow(request)
            } else {
                notifyWeb(request?.transactionId ?: "", "Permission denied", "SMS permission was not granted")
                Toast.makeText(this, "SMS permission is required to send parent messages", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun notifyWeb(transactionId: String, status: String, detail: String) {
        if (!::webView.isInitialized) return
        val id = JSONObject.quote(transactionId)
        val st = JSONObject.quote(status)
        val dt = JSONObject.quote(detail)
        runOnUiThread {
            webView.evaluateJavascript("window.onNativeSmsStatus && window.onNativeSmsStatus($id,$st,$dt);", null)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(smsReceiver) } catch (_: Exception) {}
        webView.removeJavascriptInterface("AndroidSms")
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_SEND_SMS = 701
    }
}
